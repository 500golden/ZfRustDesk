#!/usr/bin/env bash
cargo build --features flutter --release --target x86_64-apple-ios --lib
