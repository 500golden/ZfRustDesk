#!/usr/bin/env bash
cargo ndk --platform 21 --target i686-linux-android build --release --features flutter
