
/// No use, for compilation only.
int getWindowsTargetBuildNumber_() {
  return 0;
}
